#pragma once

typedef struct Rezervacija {
	int id;
	char ime_gosta[20];
	char prezime_gosta[20];
	int brojSobe;
}REZERVACIJA;